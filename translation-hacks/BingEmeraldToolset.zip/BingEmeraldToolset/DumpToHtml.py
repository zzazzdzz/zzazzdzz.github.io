import os
import sys

dump = open('TextDump.txt','rb').read().decode('utf-8').split('\n')

for i in dump:
    i += "@@@@@@"
    txt = i.split("@")[3]
    addr = i.split("@")[2]
    with open('TextDumpHtml.htm', 'ab') as fp:
        fp.write(bytes("<table><tr><td><pre>"+addr+"</pre></td><td>"+txt+"</td></tr></table>", "utf-8"))