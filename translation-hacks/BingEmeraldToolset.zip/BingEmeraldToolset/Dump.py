import os
import sys

DEBUG = 0

with open('EmeraldJP.gba', 'rb') as fp:
    FILE = fp.read()

def valid_char_at(offs):
    c = FILE[offs]
    if c == 0xfc:
        if FILE[offs+1] == 0x0c: return 3
        if FILE[offs+1] > 0x18: return -1
        return 2
    if c == 0xfd:
        if FILE[offs+1] > 0x0d: return -1
        return 2
    if (c >= 0 and c <= 0xb4) or c==0xb7 or c==0xb0 or c == 0xf0 or whitespace(c):
        return 1
    else:
        return -1
        
def whitespace(c):
    return c == 0x00 or c == 0xfa or c == 0xfb or c == 0xfe

preprocessPointers = {}
exceptions = open('ExceptionList.txt','r').read().split('\n')

def init():
    global preprocessPointers
    with open('TextDump.txt','w') as fp:
        pass # clear file
    print("preprocessing...", file=sys.stderr)
    for i in range(1, 0x800000):
        if i%0x10000==0:
            print("page %i/128..." % (i//0x10000))
        shiftOffset = (FILE[i])+(FILE[i+1]<<8)+(FILE[i+2]<<16)
        preprocessPointers[shiftOffset] = (FILE[i+3]<<8) + FILE[i+4];
    print("done, %i entries" % len(preprocessPointers), file=sys.stderr)

def valid_text(offset):
    orig_offset = offset
    if hex(offset) in exceptions:
        if DEBUG: print("text at %.6x is in exceptions" % orig_offset, file=sys.stderr)
        preprocessPointers[offset] = 0
        return True
    if not offset in preprocessPointers:
        if DEBUG: print("text at %.6x is not valid - no pointer found in ROM" % orig_offset, file=sys.stderr)
        return False
    strlen = 0
    wordlen = 0
    spacecount = 0
    lastchar = 1
    if whitespace(FILE[offset]):
        if DEBUG: print("text at %.6x is not valid - starts with whitespace" % orig_offset, file=sys.stderr)
        return False
    histogram = {}
    while FILE[offset] != 0xFF:
        if not FILE[offset] in histogram:
            histogram[FILE[offset]] = 1
        if FILE[offset] == FILE[offset+1] and FILE[offset+1] == FILE[offset+2] and FILE[offset+2] == FILE[offset+3]:
            return False
        ch = valid_char_at(offset)
        if ch == -1:
            if DEBUG: print("text at %.6x is not valid - undefined character %.2x" % (orig_offset, FILE[offset]), file=sys.stderr)
            return False
        if whitespace(FILE[offset]):
            wordlen = 0
            spacecount += 1
        else: wordlen += 1
        if wordlen > 15:
            if DEBUG: print("text at %.6x is not valid - length of a single word exceeded 15 chars" % orig_offset, file=sys.stderr)
            return False
        if whitespace(FILE[offset]) and whitespace(FILE[offset+1]):
            if DEBUG: print("text at %.6x is not valid - double spacing" % orig_offset, file=sys.stderr)
            return False
        strlen += 1
        lastchar = FILE[offset]
        offset += ch
        if offset in preprocessPointers and preprocessPointers[offset] == 0x0809:
            if DEBUG: print("text at %.6x is not valid - future part has a pre-pointer footprint of 0x0809" % orig_offset, file=sys.stderr)
            return False
    if len(histogram)<12:
        if DEBUG: print("text at %.6x is not valid - questionable character diversity" % orig_offset, file=sys.stderr)
        return False
    if lastchar == 0:
        if DEBUG: print("text at %.6x is not valid - ends with space" % orig_offset, file=sys.stderr)
        return False
    if strlen < 8:
        if DEBUG: print("text at %.6x is not valid - not repointable (%i is less than 8 chars)" % (orig_offset, strlen), file=sys.stderr)
        return False
    if strlen > 1000:
        if DEBUG: print("text at %.6x is not valid - text suspisiously large (%i is more than 1000 chars)" % (orig_offset, strlen), file=sys.stderr)
        return False
    if spacecount == 0:
        if DEBUG: print("text at %.6x is not valid - no spaces" % orig_offset, file=sys.stderr)
        return False
    if DEBUG: print("text at %.6x is valid!" % orig_offset)
    return True
    
charset = open('Charset.txt', 'rb').read().decode('utf-8').split('`')
    
def dump_text(offset):
    res_text = "%.6x@" % offset
    orig_offset = offset
    bytelen = 0
    while FILE[offset] != 0xFF:
        l = valid_char_at(offset)
        if l==2:
            res_text += ("{%.2x%.2x}" % (FILE[offset], FILE[offset+1]))
        if l==3:
            res_text += ("{%.2x%.2x%.2x}" % (FILE[offset], FILE[offset+1], FILE[offset+2]))
        else:
            res_text += charset[FILE[offset]]
        offset += l
        bytelen += l
    if res_text.count('~') > 1 and not '+' in res_text:
        res_text = 'P@' + res_text
    else:
        res_text = 'T@' + res_text
    res_text = res_text.replace('~', ' ')
    res_text = res_text.replace('+', ' ')
    # pre-pointer byte
    if not '%' in res_text and res_text.count(':') < 3:
        res_text = ('%.4x' % preprocessPointers[orig_offset]) + '@' + res_text
        with open('TextDump.txt', 'ab') as fp:
            fp.write(bytes(res_text, 'utf-8') + b"\n")
        print("%.6x -- wrote %i bytes" % (offset, bytelen), file=sys.stderr)
    return bytelen

init()
offset = 0x1dbd50
while offset <= 0x5fd500:
    if valid_text(offset):
        offset += dump_text(offset)
    else:
        offset += 1

print("finished!")
os.system("pause")