import os
import sys

l = 0x1dbd50
r = 0x5fd500

while 1:
    mid = (l+r) // 2
    print("trying from %.6x to %.6x" % (l, mid))
    os.system("python InsertText.py %.6x %.6x" % (l, mid))
    print("is it still crashing? (y/n) ")
    x = input()
    if x == 'y' or x == 'Y':
        r = mid
    if x == 'n' or x == 'N':
        l = mid
    if r-l < 10:
        print("results narrowed to: %.6x -- %.6x" % (l, r))
        os.system("pause")
        sys.exit(0)

os.system("pause")