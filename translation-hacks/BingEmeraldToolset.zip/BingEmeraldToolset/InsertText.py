import os
import sys

def pk_strlen(s):
    l = 0
    hexmode = 0
    offs = 0
    for i in s:
        if i == '{':
            hexmode = 1
            offs += 5
            continue
        if i == '}':
            hexmode = 0
            continue
        if hexmode == 1: l += 0 # ??
        else: l += 2
    return l // 2 + offs
    
def pk_convert(s):
    hexmode = 0
    bb = ''
    ret = b''
    for i in s:
        if i == '{':
            hexmode = 1
            continue
        if i == '}':
            hexmode = 0
            continue
        if hexmode > 0:
            bb += i
            if len(bb) >= 2:
                ret += bytes([int(bb, 16)])
                bb = ''
        else:
            if i in rev_charset:
                ret += bytes([rev_charset[i]])
    return ret

def prepare_string(s):
    first = True
    ret = b''
    box_width = 21
    cur_width = 0
    s = s.split(' ')
    for i in s:
        if cur_width+pk_strlen(i) > box_width:
            terminator = b'\xfa'
            if first:
                first = False
                terminator = b'\xfe'
            ret += terminator
            cur_width = 0
        if cur_width != 0:
            ret += b'\x00'
        ret += pk_convert(i)
        cur_width += pk_strlen(i)+1
        if i[-1] == '!' or i[-1] == '?' or i[-1] == '.':
            if i.count('!') <= 2 and i.count('?') <= 2 and i.count('.') <= 1:
                ret += b'\xfb'
                first = True
                cur_width = 0
    if ret[-1] == 0xfb:
        ret = ret[:-1] # + b'\xfc\x09'
    ret += b'\xff'
    return ret

with open('EmeraldJP.gba', 'rb') as fp:
    FILE = bytearray(fp.read())
    
charset = open('Charset.txt', 'rb').read().decode('utf-8').split('`')
rev_charset = {}
for i in range(0, 256):
    rev_charset[charset[i]] = i

with open('TranslatedDump.txt', 'r') as fp:
    insert = fp.read()
with open('CustomPatches.txt', 'r') as fp:
    insert += fp.read()
insert = insert.split("\n")
    
addr_whitelist = {}
with open('TextDump.txt', 'r', encoding='utf-8') as fp:
    wl = fp.read().split("\n")
    for i in wl:
        if i == '': continue
        i = i.split("@")[2]
        addr_whitelist[int(i,16)] = 1
    
ctrl = 0
current_addr = 0
insert_addr = 0xf00307

min_addr = 0x0
try:
    min_addr = int(sys.argv[1], 16)
except:
    min_addr = 0x0
    
max_addr = 0xffffff
try:
    max_addr = int(sys.argv[2], 16)
except:
    max_addr = 0xffffff


for i in insert:
    if i == '' or i == '-dbg':
        break
    if ctrl == 0:
        ctrl = 1
        current_addr = int(i, 16)
        if int(i, 16) > max_addr: continue
        if int(i, 16) < min_addr: continue
        print("\rinsert at %.6x..." % current_addr, end='')
    else:
        ctrl = 0
        if current_addr > max_addr: continue
        if current_addr < min_addr: continue
        if True or current_addr in addr_whitelist:
            t = prepare_string(i)
            start_addr = insert_addr
            for i in t:
                FILE[insert_addr] = i
                insert_addr += 1
            # todo: text types
            FILE[current_addr] = 0xFC
            FILE[current_addr+1] = 0xB5
            current_addr += 2
            FILE[current_addr] = (start_addr >> 16) & 0xFF
            FILE[current_addr+1] = (start_addr >> 8) & 0xFF
            FILE[current_addr+2] = (start_addr) & 0xFF
        
print("ok")
with open('RawPatches.txt', 'r') as fp:
    x = fp.read().split('\n')
    for i in x:
        if i == '': break
        i = i.split('@')
        addr = int(i[0],16)
        ct = pk_convert(i[1])
        print("inserting %s at %.6x" % (ct, addr))
        for i in ct:
            FILE[addr] = i
            addr += 1
        
with open('Final.gba', 'wb') as fp:
    fp.write(bytes(FILE))
    
print("writing...")
print("done!")

if len(sys.argv) == 1:
    os.system("pause")