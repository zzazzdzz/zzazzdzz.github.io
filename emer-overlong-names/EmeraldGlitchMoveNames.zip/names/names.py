
# This function will be called for each move index. Use it to find and display what you need.
# `index` - move index
# `name` - move name as a byte array, including the trailing 0xFF
# `attributes` - move attributes in 12-byte internal format
# (http://bulbapedia.bulbagarden.net/wiki/Move_data_structure_in_Generation_III)
def checkMove(index, name, attributes):
    print("Move %.4X is %i characters long. Its first char is %.2X. It has %i power."
          % (index, len(name)-1, name[0], attributes[1]))
    
with open('moves.db', 'rb') as fp:
    moves_db = fp.read()
with open('effects.db', 'rb') as fp:
    effects_db = fp.read()
    
for i in range(0, 0xFFFF+1):
    moves_offs = i * 0xD
    effects_offs = i * 0xC
    end_offs = moves_db.index(b'\xFF', moves_offs) + 1
    checkMove(i, moves_db[moves_offs : end_offs], effects_db[effects_offs : effects_offs + 0xC])
    
