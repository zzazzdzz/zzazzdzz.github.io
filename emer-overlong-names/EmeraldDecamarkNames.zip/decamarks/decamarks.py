
# This function will be called for each Pokemon index. Use it to find and display what you need.
# `index` - move index
# `name` - move name as a byte array, including the trailing 0xFF
def checkMove(index, name):
    print("Name of %.4X is %i characters long. Its first char is %.2X."
          % (index, len(name)-1, name[0]))
    
with open('names.db', 'rb') as fp:
    names_db = fp.read()
    
for i in range(0, 0xFFFF+1):
    names_offs = i * 0xB
    end_offs = names_db.index(b'\xFF', names_offs) + 1
    checkMove(i, names_db[names_offs : end_offs])
